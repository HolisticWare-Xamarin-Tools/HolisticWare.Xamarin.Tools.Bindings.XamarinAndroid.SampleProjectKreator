# facedetection
Face detection by using ML Kit in Android
For more information, you can check this article on Medium as follow: https://medium.com/kayvan-kaseb/implementing-smarter-android-apps-with-ml-kit-9fbeb8c121b1
