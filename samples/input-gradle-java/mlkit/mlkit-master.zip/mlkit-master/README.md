# MLKit Samples

A collection of quickstart samples demonstrating the [ML Kit](https://developers.google.com/ml-kit) APIs on Android and iOS.

Note: due to how this repo works, we no longer accept pull requests directly. Instead, we'll patch them internally and then sync them out.
